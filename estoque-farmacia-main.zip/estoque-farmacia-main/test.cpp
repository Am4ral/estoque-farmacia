#include <iostream>
#include <array>

using namespace std;


int main(){
    char name[50];
    cin >> name;
    cout << name;
    return 0;
}